package server;

import java.io.File;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Pattern;

import client.Client;

public class CommandeCD extends Commande {

	public CommandeCD(Socket clientSocket,String commandeStr) {
		super( clientSocket, commandeStr);
	}

	public void execute() {
		
		if(Server.currentDir == null) {
			File file = new File(".");
			String s = "Path: ";
			s =s+ file.getAbsoluteFile().toString();
			Server.currentDir=s;
			System.out.println(s);	
		}
		//On prend l'argument de cd dans une chaine
		String cdArg=commandeArgs[0];
		//On verifie si le chemin donn� existe bien 

		if (new File(cdArg).exists() ) {
			Server.currentDir="Path: " + cdArg;
			System.out.println("Changement de repertoire vers" + Server.currentDir);
		    ps.println("0 " + Server.currentDir);
		    
		}else {
			//Dans le cas ou ce n'est pas un chemin absolue 
			
			if(new File(Server.currentDir.split(" ")[1]+cdArg).exists()) {
				Server.currentDir=Server.currentDir+ cdArg;
				System.out.println("Changement de repertoire vers" + Server.currentDir);
			    ps.println("0 " + Server.currentDir);
			}else {
				System.out.println("r�pertoire non existant");
				ps.println("0 " + " r�pertoire non existant");
			}
			
			
		}
		
		
		
	}

	

}
