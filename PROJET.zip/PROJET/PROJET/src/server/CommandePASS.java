package server;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;

public class CommandePASS extends Commande {
	
	public CommandePASS(Socket clientSocket, String commandeStr) {
		super(clientSocket, commandeStr);
	}

	public void execute() {
		//On ajoute le chemin vers le mdp du client dans passPath
		
		String passPath="C:\\Users\\Hp\\Desktop\\Studies\\PROJET\\PROJET\\src\\server\\dossiers_utilisateurs\\";
		passPath=passPath+Commande.user+"\\pw.txt";
		
		
		File file1 = new File(passPath); 
		String pass=null;
		//On lit le fichier pw.txt et on stock le resultat dans pass
		
		BufferedReader br =null; 
		
		try {
		      br = new BufferedReader(new FileReader(file1));
		  } catch (FileNotFoundException ex) {
		   
		    ps.println("2 Le user " + Commande.user + " n'existe pas");
		    return;
		  }
		  try {
			  if(br !=null) {
				  pass = br.readLine();
			  }
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		
		
		//puis on compare a pass 
		  
		if(commandeArgs[0].toLowerCase().equals(pass)) {
			CommandExecutor.pwOk = true;
			if(CommandExecutor.userOk) {
				ps.println("1 Commande pass OK");
				ps.println("0 Vous êtes bien connecté sur notre serveur");
			}else {
				ps.println("2 user non fourni !!");
				ps.println("2 user non fourni !!");
			}
			
		}
		else {
			ps.println("2 Le mode de passe est faux");
		}
		
		
		
	}

}


