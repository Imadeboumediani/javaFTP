package server;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;

public class CommandeUSER extends Commande {
	
	public CommandeUSER(Socket clientSocket, String commandeStr) {
		super(clientSocket, commandeStr);
	}

	public void execute() {
			//On prend l'argument et on l'ajoute au chemin userPath
		
			String userPath="C:\\Users\\Hp\\Desktop\\Studies\\PROJET\\PROJET\\src\\server\\dossiers_utilisateurs\\";
			userPath=userPath+commandeArgs[0].toLowerCase();
			File file1 = new File(userPath); 
			  
			BufferedReader br =null;  
			
			//On verifie donc si l'utilisateur existe en verifiant si son repertoire existe  
			
			if (file1.exists()) {
				CommandExecutor.userOk = true;
				Commande.user=commandeArgs[0].toLowerCase();
				ps.println("0 Commande user OK");
			}else {
				ps.println("2 Le user " + commandeArgs[0] + " n'existe pas");
			}
			
			 
			  
			 
			 	
	}

}
