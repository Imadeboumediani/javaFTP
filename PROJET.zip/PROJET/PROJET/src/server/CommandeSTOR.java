package server;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;

public class CommandeSTOR extends Commande {
	
	public CommandeSTOR(Socket clientSocket, String commandeStr) {
		super( clientSocket, commandeStr);
	}

	public void execute() {
		
	}

}
