package client;

import java.net.Socket;
import java.net.UnknownHostException;

import server.CommandExecutor;
import server.Server;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Writer;

public class Client {

	public static Socket socket = null;
	public static BufferedReader reader;
	public static PrintStream writer;
	public static String currentDir;
	public static void main(String[] args) {
		

		String hostname = "localhost";
		int port = 2022;

		String message = "", commande = "";

		try {

			socket = new Socket(hostname, port);
			reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			writer = new PrintStream(socket.getOutputStream());

			// read from server
			message = reader.readLine();
			System.out.println(message.split(" ", 2)[1]);

			message = reader.readLine();
			System.out.println(message.split(" ", 2)[1]);

			message = reader.readLine();
			System.out.println(message.split(" ", 2)[1]);

			//Tant que commande n'est pas egale a bye 
			do {
				//On affiche Client.currentDir avant le ">" comme dans un terminale Linux une fois la variable Client.currentDir rempli apres un pwd ou cd
				if(Client.currentDir!=null) {
					System.out.print(Client.currentDir + " >");
				}else {
					System.out.print(">");
				}
				
				//On recupere la commande
				
				commande = getCommande();
				
				//On envoie la commande
				
				writer.println(commande);
				
				//Dans le cas ou la commande est un store et get , ceci n'est qu'un test de store et get qui ne fonctionne pas encore 
				switch (commande.split(" ")[0].toLowerCase()) {

					case "store": {
						storeFileInServer(commande.split(" ")[1].toLowerCase());
						break;
					}
	
					case "get":
						getFileFromServer(commande.split(" ")[1].toLowerCase());
						break;
					default: {
	
						break;
					}

				}

				do {
					//On lit le message
					
					message = reader.readLine();
				
					//Au cas ou le message contient Path on deuxieme place , c'est un cd ou pwd , on stock donc le chemin dans Client.currentDir
					if(message.split(" ")[1].equals("Path:") ) {
						
						Client.currentDir=message.split(" ")[2];
						System.out.println(Client.currentDir);
					}else {
						
						System.out.println(message.split(" ", 2)[1]);
					}
					
					
				} while (message.split(" ")[0].equals("1")); //On continue 

			} while (!commande.equals("bye"));
			
			reader.close();
			writer.close();
			socket.close();
			
		} catch (UnknownHostException ex) {

			System.out.println("Server not found: " + ex.getMessage());

		} catch (IOException ex) {

			System.out.println("Le serveur est deconnete. Merci");
		}

	}

	private static void getFileFromServer(String name) {


		//ps.println("0 Uploading File.");
		
		String fileName="" ;
		//= commandeArgs[0].toLowerCase();
		
		byte[] buffer = new byte[1024];   
        int bytesRead;
        int current = 0;
        long size;
        
		try {
			
			DataInputStream clientData = new DataInputStream(socket.getInputStream()); 
	         
	        fileName = clientData.readUTF();   
	        OutputStream output = new FileOutputStream(fileName);  
			size = clientData.readLong();
			
	        while (size > 0 && (bytesRead = clientData.read(buffer, 0, (int)Math.min(buffer.length, size))) != -1)   
	        {   
	            output.write(buffer, 0, bytesRead);   
	            size -= bytesRead;   
	        }
	         
	        // Closing the FileOutputStream handle
	        output.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
        
		
		writer.println("0 Le Fichier a ete telecharger .");
		
	}

	private static void storeFileInServer(String path) {

		// Send file
		File myFile = new File(path);
		byte[] mybytearray = new byte[(int) myFile.length()];

		FileInputStream fis;
		try {
			fis = new FileInputStream(myFile);
			BufferedInputStream bis = new BufferedInputStream(fis);
			// bis.read(mybytearray, 0, mybytearray.length);

			DataInputStream dis = new DataInputStream(bis);
			dis.readFully(mybytearray, 0, mybytearray.length);

			OutputStream os = socket.getOutputStream();

			// Sending file name and file size to the server
			DataOutputStream dos = new DataOutputStream(os);
			dos.writeUTF(myFile.getName());
			dos.writeLong(mybytearray.length);
			dos.write(mybytearray, 0, mybytearray.length);
			dos.flush();

			// Sending file data to the server
			// os.write(mybytearray, 0, mybytearray.length);
			// os.flush();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

		}

	}

	private static String getCommande() {
		
		//On recup�re la commande et on la retourne

		String cmd = "";

		BufferedReader obj = new BufferedReader(new InputStreamReader(System.in));
		try {
			cmd = obj.readLine().toLowerCase();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println(e.toString());
		}

		return cmd;
	}

}
